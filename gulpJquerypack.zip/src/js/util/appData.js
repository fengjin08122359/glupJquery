var appData = {
  dialgoue: null,
  businessList: null
}
module.exports = appData
